from .home import WeeklyHome

home = WeeklyHome.as_view()

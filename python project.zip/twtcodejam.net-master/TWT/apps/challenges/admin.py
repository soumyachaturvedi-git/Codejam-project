from django.contrib import admin
from .models import Challenge, CustomPage, Timer
admin.site.register(Challenge)
admin.site.register(CustomPage)
admin.site.register(Timer)